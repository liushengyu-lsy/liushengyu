//1.导包，找到Scanner这个类在哪，注意要写在类定义上面
import java.util.Scanner;
public class keyboard
{
    public static void main(String []args)
    {
//2.创建对象，表示我现在准备要用Scanner这个类
        Scanner sc=new Scanner(System.in);
        System.out.println("请输入整数");
//3.接收数据
//变量：记录了键盘录入的数据
        int i=sc.nextInt();
        System.out.println("请再次输入整数");
        int j=sc.nextInt();
        System.out.println(i);
        System.out.println(j);
    }
}