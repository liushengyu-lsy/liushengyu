package idea.heima.demo1;

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("HelloWorld");
        //定义一个字符串为我爱你
        String str = "我爱你";
        //打印这个字符串
        System.out.println(str);
        //定义一个变量记录整数10
        int num = 10;
        // //定义一个变量记录整数20
        int num2=0 ;
        //定义一个变量记录两个变量之商
        int num3;
         if(num2!=0){num3= num / num2;      System.out.println(num3);}
         else System.out.println("除数不能为0");




    }
}
