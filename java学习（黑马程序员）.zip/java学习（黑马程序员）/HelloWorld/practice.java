package jia.you;

import java.util.Scanner;

public class practice {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("请输入一个整数");
        int num1=sc.nextInt();
        System.out.println("请输入一个整数");
        int num2=sc.nextInt();
       boolean flag=num1>num2;
        System.out.println(flag);
    }
}
