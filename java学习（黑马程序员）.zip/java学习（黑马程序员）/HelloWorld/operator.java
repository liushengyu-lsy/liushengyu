package jia.you;

import java.util.Scanner;

public class operator {

	public static void main(String[] args) {
        int a=100,b=56;
        System.out.println(a&b);
        System.out.println(a<<1);
        System.out.println(b>>2);
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入一个整数");
        int num1 = sc.nextInt();
        System.out.println("请输入另一个整数");
        int num2=sc.nextInt();
        System.out.println(num1|num2);

	}
}
