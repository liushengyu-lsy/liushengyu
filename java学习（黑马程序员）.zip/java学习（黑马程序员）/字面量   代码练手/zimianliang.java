public class zimianliang
{
                  public static void main(String[] args)
{
                               //打印字符串；  
                               System.out.println("HelloWorld");
                               System.out.println("xxy");
                               //打印整型； 
                               System.out.println(771);  
				//打印小数类型;
				System.out.println(771.631);
				//打印字符类型;
				System.out.println('谢');
				//打印布尔类型;
				System.out.println(true);     
				System.out.println(false);
				//想打印null类型，但是要通过字符串的形式才行，因为只打印null不显示；
				System.out.println("null");                                     
} 
}          