package wo.hen.aini;

public class role_Play {
    public static void main(String[] args) {
        Role player1=new Role("吕布",100,'男');
        Role player2=new Role("秦始皇",100,'男');
        player1.introduce();
        player2.introduce();
        while(true)
        {
            player1.attack(player2);
            if(player2.getBlood()==0)
            {
                System.out.println(player1.getName()+"beats"+player2.getName());
                break;
            }
            player2.attack(player1);
            if(player1.getBlood()==0)
            {
                System.out.println(player2.getName()+"beats"+player1.getName());
                break;
            }

        }
    }
}
