package wo.hen.aini;

import jdk.swing.interop.SwingInterOpUtils;

import java.sql.SQLOutput;


public class studentLsy {
    public static void main(String[] args) {
       Student lsy=new Student();
        lsy.setname("lsy");
       lsy.setscore(-10);
       System.out.println(lsy.getname());
       System.out.println(lsy.getscore());
lsy.speak();
    }
}
