package wo.hen.aini;

import java.util.Random;
import java.util.Scanner;

public class union_lotto {
    //1,随机生成6个红球号码（1到33）和1个蓝球号码（1到16），但是红球号码不能重复；
    //2，用户输入6个红球号码和1个蓝球号码；
    //3，判断用户的中奖情况；
    //4，输出中奖情况；
    public static void main(String[] args)
    {int[] arr=randomnumber();
//    for(int i=0;i<arr.length;i++)
//    {
//        System.out.println(arr[i]);
//    }
        //用户输入6个红球号码和1个蓝球号码；
        int[]userarr=new int[7];
        Scanner sc=new Scanner(System.in);
        int rednumber;
        for(int i=0;i<6;)//这里可以不用先i++那么快，是为了后面检验输入的值是否在范围内再i++；
        {
            System.out.println("请输入第"+(i+1)+"个红球号码");
            rednumber=sc.nextInt();
            if(rednumber>=1&&rednumber<=33)
            {
                if(!testnumber(userarr,rednumber))
                {
                    userarr[i]=rednumber;
                    i++;//至此，红球号码才能正确输入到userarr中
                }
                else
                {
                    System.out.println("输入的红球号码重复，请重新输入");
                }
            }
            else
            {
                System.out.println("输入的红球号码不在范围内，请重新输入");
            }
            //至此，所有红球号码全部正确地输入到数组里面；
        }
        System.out.println("请输入蓝球号码");
        while(true) {
            int bluenumber = sc.nextInt();
            if (bluenumber >= 1 && bluenumber <= 16) {
                userarr[6] = bluenumber;
                break;
            } else {
                System.out.println("输入的蓝球号码不在范围内，请重新输入");
            }
        }//蓝球号码输入成功

        //判断用户的中奖情况；
        int redcount=0,bluecount=0;
        for(int i=0;i<arr.length-1;i++)
        {
            for(int j=0;j<arr.length-1;j++)
            {
                if(arr[i]==userarr[j])
                {
                    redcount++;
                    break;
                }
            }
        }
        if(arr[6]==userarr[6])
            bluecount++;
      if(redcount==6)
      {
          if(bluecount==1)
              System.out.println("恭喜你，中了一等奖，有了资本挽留");
          else System.out.println("恭喜你，中了二等奖，仍然可以挽留");
      }
      else if(redcount==5)
      {
          if(bluecount==1)
              System.out.println("恭喜你，中了三等奖，但是如果你运气再好一点再多一个红球，可能就可以获得五百万");
          else System.out.println("很遗憾，差一个蓝球，但是你还是你错过她了");
      }
      else if(redcount==4)
      {
          if(bluecount==1)
              System.out.println("恭喜你，中了四等奖，只是你中几等奖她都不在乎");
          else System.out.println("很遗憾，差一点，主动了没有结果，就不是错过了");
      }
      else if(redcount==3)
        {
            {
                if(bluecount==1)
                    System.out.println("恭喜你，中了五等奖");
                else System.out.println("很遗憾，你还是在她的全世界路过了");
            }
        }
      else if(redcount==1)
      {
          {
              if(bluecount==1)
                  System.out.println("恭喜你，中了六等奖,但是有什么用呢，付出了那么多，能回本吗？");
              else System.out.println(
                      "这次不遗憾了，怪自己运气不好吧");
          }
      }
      else
      {
          System.out.println("多睡几觉吧，这次是离大奖越来越远了，心痛，后悔自己为什么不提前，再提前点");
      }
    }
//随机生成6个红球号码；
    public static int[] randomnumber() {
        Random c = new Random();
        int[] arr = new int[7];
        for (int i = 0; i < arr.length-1; )
        {
            int rednumber = c.nextInt(33) + 1;
            if(!testnumber(arr,rednumber))
            {
                arr[i]=rednumber;
                i++;
            }
        }

        //随机生成蓝球号码；
        int bluenumber=c.nextInt(16) + 1;
        arr[6]=bluenumber;
   return arr;
    }

    //检验是否存在重复数字；
    public static boolean testnumber(int []arr,int number)
    {
        for(int i=0;i<arr.length;i++)
        {
            if(arr[i]==number)
                return true;
        }
        return false;
    }
}