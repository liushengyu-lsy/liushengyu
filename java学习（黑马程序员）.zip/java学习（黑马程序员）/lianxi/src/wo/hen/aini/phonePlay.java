package wo.hen.aini;

import java.util.Scanner;

public class phonePlay {
    public static void main(String[] args) {
    phone []arr=new phone[3];
    Scanner sc=new Scanner(System.in);
    for(int i=0;i<arr.length;i++)
    {
        phone p=new phone();
        System.out.println("请输入手机品牌：");
        p.setBrand(sc.next());
        System.out.println("请输入手机价格：");
        p.setPrice(sc.nextInt());
        System.out.println("请输入手机芯片：");
        p.setChip(sc.next());
        arr[i]=p;
    }
        for (phone phone : arr) {
            System.out.println(phone.getBrand() + " " + phone.getPrice() + " " + phone.getChip());
        }
    }
}
