package wo.hen.aini;

import java.util.Random;
import java.util.Scanner;

//在1到100之间随机猜数
//连续猜三次也可以输出猜中
public class guessnumber {
    public static void main(String[] args) {
        Random r = new Random();
        int randomnumber = r.nextInt(100) + 1;

        int count = 0;

        while (true) {
            System.out.println("请输入你猜的数字");
            int guessnumber = new Scanner(System.in).nextInt();
            count++;

            if (count == 3) {
                System.out.println("猜中了");
                break;
            }
            if (guessnumber > randomnumber) {
                System.out.println("猜大了");
            }

           else if (guessnumber < randomnumber) {
                System.out.println("猜小了");
            }
            else  {
                System.out.println("猜中了");
                break;
            }
        }
    }
}