package wo.hen.aini;

import java.util.Random;

public class draw_lotto
{   //抽奖，每一次都可以抽中有效数字，而且保证每一次抽奖的数字都不一样；
    //可以直接把奖金放在数组里面，然后打乱数组，然后输出；
    public static void main(String[] args) {
        int []lotto={8,88,888,8888,88888};
        Random c=new Random();
        for(int i=0;i<lotto.length;i++)
        {
            int ndex=c.nextInt(lotto.length);
            int temp=lotto[ndex];
           lotto[ndex]=lotto[i];
            lotto[i]=temp;

        }
        for(int i=0;i<lotto.length;i++)
        {
            System.out.println(lotto[i]);
        }
    }
}
