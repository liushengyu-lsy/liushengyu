package wo.hen.aini;

import java.util.StringJoiner;

public class stringJoiner {
    public static void main(String[] args) {
        StringJoiner sc=new StringJoiner(",","[","]");
        sc.add("abc").add("defg");
        String str=sc.toString();
        System.out.println(str);
    }
}
