package wo.hen.aini;

import java.util.Scanner;

public class methoddemo2 {
    public static void main(String[] args)


        {//调用方法求长方形的周长；
            Scanner sc=new Scanner(System.in);
            System.out.println("请输入长方形的长");
            int length=sc.nextInt();
            System.out.println("请输入长方形的宽");
            int width=sc.nextInt();
            calculate(length,width);
        }
        public static int calculate(int length,int width)
        {
            int sum=(length+width)*2;
            System.out.println("长方形的周长为：");
            System.out.println(sum);
            return sum;
        }
    }



