package wo.hen.aini;

import java.util.Scanner;

public class stringIntercept {
    public static void main(String[] args) {
        System.out.println("请输入一个手机号码，自动帮你屏蔽掉中间的数字");
        Scanner sc=new Scanner(System.in);
        String phoneNumber=sc.next();
        String first=phoneNumber.substring(0,3);
        String end=phoneNumber.substring(7);
        String result=first+"****"+end;
        System.out.println(result);
        //替换字符串中的数字
        System.out.println(phoneNumber.replace("2760","2227"));

    }
}
