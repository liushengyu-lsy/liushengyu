package wo.hen.aini;

import java.awt.*;

public class phone {
    private String brand;
    private int price;
    private String chip;

    public phone() {
    }

    public phone(String brand, int price, String chip) {
        this.brand = brand;
        this.price = price;
        this.chip = chip;
    }

    /**
     * 获取
     * @return brand
     */
    public String getBrand() {
        return brand;
    }

    /**
     * 设置
     * @param brand
     */
    public void setBrand(String brand) {
        this.brand = brand;
    }

    /**
     * 获取
     * @return price
     */
    public int getPrice() {
        return price;
    }

    /**
     * 设置
     * @param price
     */
    public void setPrice(int price) {
        this.price = price;
    }

    /**
     * 获取
     * @return chip
     */
    public String getChip() {
        return chip;
    }

    /**
     * 设置
     * @param chip
     */
    public void setChip(String chip) {
        this.chip = chip;
    }

    public String toString() {
        return "phone{brand = " + brand + ", price = " + price + ", chip = " + chip + "}";
    }
}
