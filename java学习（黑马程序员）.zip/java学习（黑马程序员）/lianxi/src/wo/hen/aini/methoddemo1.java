package wo.hen.aini;

public class methoddemo1 {
    public static void main(String[] args) {
        loveprocess();
        loveprocess();
    }
    public static void loveprocess() {
        System.out.println("i love you");
        System.out.println("can we be friend? ");
        System.out.println("can we still be friend?");
    }
}
