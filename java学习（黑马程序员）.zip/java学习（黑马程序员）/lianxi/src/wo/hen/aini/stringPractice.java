package wo.hen.aini;

import java.util.Scanner;

public class stringPractice {
    public static void main(String[] args)
    {

        String s1="abc";
        Scanner sc=new Scanner(System.in);
        String s2=sc.nextLine();
        System.out.println((s1.equals(s2)));
        System.out.println((s1.equalsIgnoreCase(s2)));
    }
}
