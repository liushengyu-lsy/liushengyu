package wo.hen.aini;

import com.sun.jdi.PathSearchingVirtualMachine;

import java.awt.font.OpenType;
import java.util.Scanner;

public class travelString {

    public static void main(String[] args) {
        //遍历字符串
        Scanner sc=new Scanner(System.in);
        String string=sc.next();
        //记录大小写字母和数字以及其他字符出现的次数
        int bigcount=0;
        int smallcount=0;
        int numbercount=0;
        int othercount=0;
        for(int i=0;i<string.length();i++)
        {
            int c=string.charAt(i);
            if(c>='0' && c<='9')
            {
                numbercount++;
            }
            else if(c>='a' && c<='z')
            {
                smallcount++;
            }
            else if(c>='A' && c<='Z')
            {
                bigcount++;
            }
            else othercount++;
        }
        System.out.println("大写字母出现次数为"+bigcount);
        System.out.println("小字母出现次数为"+smallcount);
        System.out.println("数字出现次数为"+numbercount);
        System.out.println("其他字符出现次数为"+ othercount);
    }
}
