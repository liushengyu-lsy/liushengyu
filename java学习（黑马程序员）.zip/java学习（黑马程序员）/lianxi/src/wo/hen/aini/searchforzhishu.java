package wo.hen.aini;

public class searchforzhishu {

    //寻找1到150之间的质数；
    public static void main(String[] args) {
        int i = 150;
        int count = 0;

        for (int j = 3; j <= i; j++)
        { boolean flag = true;
            for (int k = 2; k < j; k++)
            {
                if (j % k == 0)
                {
                    flag = false;
                    break;
                }
            }
                if (flag) {
                    count++;
                    System.out.println(j + "是质数");
                }

        }


    }
}