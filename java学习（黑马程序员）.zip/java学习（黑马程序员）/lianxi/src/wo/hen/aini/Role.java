package wo.hen.aini;

import java.util.Random;

public class Role {
    private String name;
    private int blood;
    private char gender;
    private String face;// 从后面的长相数组中随机抽一个长相出来；
    String []maleface={"剑眉星眸","清新俊逸" ,"挺鼻薄唇" ,"风流倜傥", "潇洒英俊"};
    String []femaleface={"尽善尽美","倾国倾城","温文尔雅","出水芙蓉","国色天香"};
//技能描述
    String []kungFu={"%s使出一记天马流星拳，把%s打的不知所措"
        ,"%s使出一招凌波微步，径直在空中踏步，一个化骨绵掌直接掠向%s",
        "%s双脚迈开，蓄力后打出一招降龙十八掌，打的%s，连连败退",
        "%s使出一招万剑归宗，把%s的所有武器都收了起来",
        "%s运气于手掌，一瞬间掌心变得血红，一式掌心雷，推向%s"};

    //受伤描述
    String[]injury_desc={"结果%s退了半步，毫发无损","结果给%s造成了一处瘀伤","结果一击命中，%s痛的弯下了腰","结果%s痛苦地闷哼一声，显然伤得不轻","结果%s摇摇晃晃，一跤摔倒在地","结果%s脸色一下子变得惨白，连退了好几步","结果一声巨响，%s口中鲜血狂涌","结果%s一声惨叫，像滩软泥般塌了下去"};
//开始Javabean
    public Role() {
    }

    public Role(String name, int blood, char gender) {
        this.name = name;
        this.blood = blood;
        this.gender = gender;
       setFace(gender);
    }
 //角色介绍
    public void introduce()
    {
        System.out.println("姓名为："+getName());
        System.out.println("血量为："+getBlood());
        System.out.println("性别为："+getGender());
        System.out.println("长相为："+getFace());
    }

    public String getName() {
        return name;
    }


    public void setName(String name) {
        this.name = name;
    }


    public int getBlood() {
        return blood;
    }


    public void setBlood(int blood) {
        this.blood = blood;
    }


    public char getGender() {
        return gender;
    }


    public void setGender(char gender) {
        this.gender = gender;
    }


    public String getFace() {
        return face;
    }

    public void setFace(char gender) {
    Random c=new Random();
    //随机长相
    if(gender=='男')
    {
        this.face=maleface[c.nextInt(maleface.length)];
    }
    else if(gender=='女')
    {
        this.face=femaleface[c.nextInt(femaleface.length)];
    }
    }

    //攻击
    public void attack(Role role)
    { Random c=new Random();
        int hurt=c.nextInt(10)+1;
        //剩余的血量
        int leftblood=role.getBlood()-hurt;
        leftblood=leftblood<0?0:leftblood;
        role.setBlood(leftblood);
        //随机攻击
        String wuShu=kungFu[c.nextInt(kungFu.length)];
        //输出一个攻击的效果
        System.out.printf(wuShu,this.name,role.getName());
        System.out.println();
        //受伤的描述,用souf来输出，这样参数分两部分，带%s%d这种，跟C语言类似
        if(leftblood>90)
        {
            System.out.printf(injury_desc[0],this.name);
        }
        else if(leftblood>80&&leftblood<=90)
        {
            System.out.printf(injury_desc[1],this.name);
        }
        else if(leftblood>70&&leftblood<=80)
        {
            System.out.printf(injury_desc[2],this.name);
        }
        else if(leftblood>60&&leftblood<=70)
        {
            System.out.printf(injury_desc[3],this.name);
        }
        else if(leftblood>50&&leftblood<=60)
        {
            System.out.printf(injury_desc[4],this.name);
        }
        else if(leftblood>40&&leftblood<=50)
        {
            System.out.printf(injury_desc[5],this.name);
        }
        else if(leftblood>10&&leftblood<=40)
        {
            System.out.printf(injury_desc[6],this.name);
        }
        else
        {
            System.out.printf(injury_desc[7],this.name);
        }
        System.out.println();
    }

//    public String toString() {
//        return "Role{name = " + name + ", blood = " + blood + ", gender = " + gender + ", face = " + face + ", maleface = " + maleface + ", femaleface = " + femaleface + "}";
//    }
}
