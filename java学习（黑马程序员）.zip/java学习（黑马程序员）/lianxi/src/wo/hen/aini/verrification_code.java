package wo.hen.aini;

import java.util.Random;
//随机生成前四位是大小写字母，最后一位是数字的五位验证码

public class verrification_code {
    public static void main(String[] args) {
        Random c = new Random();
        //把字母存储在数组里面
        char[] word = new char[52];
        for (int i = 0; i < word.length; i++) {
            if (i < 26)
                word[i] = (char) (65 + i);
            else if (i >= 26)
                word[i] = (char) (97 + i - 26);
            //System.out.print(word[i]);
        }
        //
        //定义一个字符串记录随机生成的四个字母
        String result = "";
        for (int i = 0; i < 4; i++)
        {
            result += word[c.nextInt(word.length)];
        }
        result+=c.nextInt(9);
        System.out.println(result);
    }
}