package wo.hen.aini;

public class Student {
    private String name;
    private double score;

    public void setname(String a)
    {
        name=a;
    }
   public String getname()
   {
       return name;
   }
    public void setscore(double b)
    {
        if (b >= 0 && b <= 100) {
            score = b;
        } else
        {
            System.out.println("error");
        }
    }
    public double getscore()
    {
        return score;
    }
    public  void speak()
    {
        System.out.println("i hate her");
    }
}
