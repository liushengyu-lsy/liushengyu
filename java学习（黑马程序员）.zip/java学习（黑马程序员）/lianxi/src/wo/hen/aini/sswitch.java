package wo.hen.aini;

import java.util.Scanner;

public class sswitch {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入星期几");
        int weekday = sc.nextInt();
        switch (weekday) {
            case 1, 2, 3, 4, 5 -> {
                System.out.println("工作日8");
            }
            case 6, 7 -> {
                System.out.println("周末");
            }
            default -> {
                System.out.println("输入错误");
            }
        }
    }
}