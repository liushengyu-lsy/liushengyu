package wo.hen.aini;

public class copy {

    public static void main(String[] args) {
        int[] nums = {1, 2, 3, 4, 5};
        int[]copy=copyrange(nums,1,3);
        for (int i = 0; i < copy.length; i++) {
            System.out.println(copy[i]);
        }
    }
    public static int[] copyrange(int[] nums, int start, int end)
    {
        int[] copy = new int[end - start];
        int flag=0;
        for(int i=start;i<end;i++)
        {copy[flag++]=nums[i];}
        return copy;

    }
}
