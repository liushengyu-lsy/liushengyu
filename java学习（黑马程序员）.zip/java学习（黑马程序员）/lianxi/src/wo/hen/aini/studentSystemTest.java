package wo.hen.aini;

import java.util.Scanner;

/*要求1 在已经创建好的数组中添加一名学生，并进行唯一性判断；
要求2 遍历所有学生信息；
要求3 通过id删除学生信息；
要求4 删除完毕后，遍历；
要求5 查询数组id为“lsy666”的学生信息，若存在，则将她的年龄加一岁；
跟C语言的课设差不多
*/
public class studentSystemTest {
    public static void main(String[] args) {
        //先创建好数组的信息
        studentSystem []arr=new studentSystem[3];
        arr[0]=new studentSystem(1,"张三",18);
        arr[1]=new studentSystem(2,"李四",19);
        arr[2]=new studentSystem(3,"王五",20);
        //添加一名学生
        studentSystem stu=new studentSystem(4,"赵六",21);
//使用confirmId方法判断是否有重复的id

        if(confirmId(arr,stu.getId()))
        {
            System.out.println("id重复");
        }
        else
        {//开始将创建的对象添加到数组中，但是要先用confirmNumber方法判断数组是否已满
            int count=confirmNumber(arr);
            if(count==arr.length)
            {
                studentSystem []arr1=new studentSystem[arr.length+1];
                for(int i=0;i<arr.length;i++)
                {
                    arr1[i]=arr[i];
                }
                arr1[arr.length]=stu;
                printfArr(arr1);
                System.out.println("请输入你要查询的id：");
                Scanner sc=new Scanner(System.in);
                int index=sc.nextInt();
                int symbol=findIndex(arr1,index);
                if(symbol==-2)
                {
                    System.out.println("id不存在");
                }
                else{
                    arr1[symbol]=null;
                    //第四步遍历数组
                    printfArr(arr1);
                }
            }
            else
            {
                arr[count]=stu;
                printfArr(arr);
                System.out.println("请输入你要查询的id：");
                Scanner sc=new Scanner(System.in);
                int index=sc.nextInt();
                int symbol=findIndex(arr,index);
                if(symbol==-2)
                {
                    System.out.println("id不存在");
                }
                else{
                    arr[symbol]=null;
                    printfArr(arr);
                }
            }
        }





    }
   //判断是否有重复的id
    public static boolean confirmId(studentSystem[]arr,int id)
    {
        for (wo.hen.aini.studentSystem studentSystem : arr) {
            //为了避免数组未满时出现空指针异常，我们在这里使用if语句判断
            if (studentSystem != null) {
                if (studentSystem.getId() == id) {
                    return true;
                }
            }
        }
        return false;
    }

    //使用方法判断创建的对象是否已满；
    public static int confirmNumber(studentSystem[]arr)
    {    int count=0;
        for (wo.hen.aini.studentSystem studentSystem : arr) {
            if (studentSystem != null) {
                count++;
            }
        }
            return count;

    }
    //要求2，遍历数组，以为不知道数组是否已经满了，所以可能要打印两遍，为了方便，我们在这里使用方法来打印
    public static void printfArr(studentSystem []arr)
    {
        for (wo.hen.aini.studentSystem studentSystem : arr) {
            if (studentSystem != null) {
                System.out.println(studentSystem.getId() + " " + studentSystem.getName() + " " + studentSystem.getAge() + " ");
            }
        }
    }
    public static int findIndex(studentSystem []arr,int id)
    {
        for (int i = 0; i < arr.length; i++)
        {
            if (arr[i]!= null) {
                if (arr[i].getId() == id) {
                    return i;
                }
            }
        }
        return -2;
    }
}