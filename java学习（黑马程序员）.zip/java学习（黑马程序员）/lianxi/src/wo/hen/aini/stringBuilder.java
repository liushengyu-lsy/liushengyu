package wo.hen.aini;

public class stringBuilder {
    public static void main(String[] args) {
//        StringBuilder sb=new StringBuilder("woaini");
//        //添加
//        sb.append("mama");
//        System.out.println(sb);
//        //倒置
//        sb.reverse();
//        System.out.println(sb);
//        //获取长度
//        System.out.println(sb.length());
//
//
//        //注意，我们这些方法用完后sb还是StringBUilder对象，它依然不是字符串，所以我们要把它转为字符串，需要用到public String toString（）方法
//        String str=sb.toString();
//        System.out.println(str);
        //试试不创建StringBuilder，通过字符串直接用replace等语句，append用不了
       //链式编程
        String str="abc";
        String refrush=str.substring(0).replace("a","d");
        System.out.println(refrush);
    }
}
