package wo.hen.aini;

import java.util.Scanner;

public class huiwenshu {
    public static void main(String[] args) {
        
        System.out.println("请输入你想判断的回文数");
        int num = new Scanner(System.in).nextInt();
        int temp = num;
        int sum = 0;
       for(;num!=0;num/=10)
       {
           sum = sum*10+num%10;
       }

       System.out.println(sum==temp);


    }
}
