public class demo3
{ public static void main(String []args)
{  String name="陈平安";
  int age=18;
double height=183.1;
char sex='男';
boolean flag=true;
System.out.println(name);
System.out.println(age);
System.out.println(height);
System.out.println(sex);
System.out.println(flag);
}
}

