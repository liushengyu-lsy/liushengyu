public class demo1
{public static void  main(String[] args)
{System.out.println("abcdeg");
System.out.println("abc"+"deg");
System.out.println("lsy"+"xxy");
System.out.println("lsy"+'\t'+"xxy");
System.out.println("lllsy"+'\t'+"十月初十");
System.out.println("xxy"+'\t'+"元宵");
}
}