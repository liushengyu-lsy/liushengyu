public class demo2
{ public static void main(String [] args)
{short a=10;
   byte b=20;
int i=30;
float d=10.2F;
double r=10.22;
long n=999999999999L;
char c='w';
System.out.println(n);
}
}